# Software FJ — Actividad 4

Sistema integral de gestión de clientes, servicios y reservas desarrollado en Python con programación orientada a objetos y manejo robusto de excepciones.

## Requisitos
- Python 3.10 o superior.
- No requiere instalar paquetes externos.

## Ejecución
Desde la carpeta del proyecto:

```bash
python main.py
```

El programa ejecuta 12 operaciones de demostración. Los eventos y errores quedan registrados en `logs/software_fj.log`.

## Estructura
- `main.py`: clases, validaciones, excepciones, gestión en memoria y demostración.
- `logs/`: archivo de registro generado al ejecutar el programa.
- `README.md`: instrucciones del proyecto.

## Consideraciones
Los datos se almacenan en listas y objetos durante la ejecución. No se utiliza base de datos. El archivo de log se usa exclusivamente para registrar eventos y errores.
