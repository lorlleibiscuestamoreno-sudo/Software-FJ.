"""
Software FJ - Sistema Integral de Gestión de Clientes, Servicios y Reservas
Actividad 4: Manejo robusto de excepciones y programación orientada a objetos.

Ejecución:
    python main.py

No utiliza bases de datos. Los datos se administran en objetos y listas en memoria.
El archivo logs/software_fj.log conserva eventos y errores de ejecución.
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from datetime import datetime
from enum import Enum
import logging
from pathlib import Path
from typing import Optional


# --------------------------- Registro de eventos ---------------------------

LOG_DIR = Path(__file__).parent / "logs"
LOG_DIR.mkdir(exist_ok=True)
logging.basicConfig(
    filename=LOG_DIR / "software_fj.log",
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s",
    encoding="utf-8",
)
logger = logging.getLogger("SoftwareFJ")


# --------------------------- Excepciones propias ---------------------------

class SoftwareFJError(Exception):
    """Excepción base para los errores controlados del sistema."""


class ValidacionError(SoftwareFJError):
    """Se genera cuando un dato no cumple las reglas de validación."""


class ServicioNoDisponibleError(SoftwareFJError):
    """Se genera cuando se intenta reservar un servicio inactivo."""


class ReservaError(SoftwareFJError):
    """Se genera cuando una operación de reserva no está permitida."""


class ClienteDuplicadoError(SoftwareFJError):
    """Se genera cuando se registra un documento ya existente."""


# --------------------------- Entidad abstracta -----------------------------

class Entidad(ABC):
    """Representa una entidad general identificada de forma única."""

    def __init__(self, identificador: str):
        if not isinstance(identificador, str) or not identificador.strip():
            raise ValidacionError("El identificador es obligatorio.")
        self._identificador = identificador.strip()

    @property
    def identificador(self) -> str:
        return self._identificador

    @abstractmethod
    def resumen(self) -> str:
        """Devuelve una descripción breve de la entidad."""


# ------------------------------- Cliente -----------------------------------

class Cliente(Entidad):
    """Cliente con datos encapsulados y validaciones estrictas."""

    def __init__(self, documento: str, nombre: str, correo: str, telefono: str):
        super().__init__(documento)
        self.__nombre = self._validar_texto(nombre, "nombre")
        self.__correo = self._validar_correo(correo)
        self.__telefono = self._validar_telefono(telefono)

    @staticmethod
    def _validar_texto(valor: str, campo: str) -> str:
        if not isinstance(valor, str) or len(valor.strip()) < 2:
            raise ValidacionError(f"El {campo} debe contener al menos 2 caracteres.")
        return valor.strip()

    @staticmethod
    def _validar_correo(correo: str) -> str:
        if not isinstance(correo, str) or "@" not in correo or "." not in correo.split("@")[-1]:
            raise ValidacionError("El correo electrónico no tiene un formato válido.")
        return correo.strip().lower()

    @staticmethod
    def _validar_telefono(telefono: str) -> str:
        if not isinstance(telefono, str) or not telefono.replace("+", "").isdigit():
            raise ValidacionError("El teléfono solo debe contener dígitos y, opcionalmente, +.")
        if len(telefono.replace("+", "")) < 7:
            raise ValidacionError("El teléfono debe tener al menos 7 dígitos.")
        return telefono.strip()

    @property
    def nombre(self) -> str:
        return self.__nombre

    @property
    def correo(self) -> str:
        return self.__correo

    @property
    def telefono(self) -> str:
        return self.__telefono

    def resumen(self) -> str:
        return f"Cliente: {self.nombre} | Documento: {self.identificador}"


# ------------------------------- Servicios ---------------------------------

class Servicio(Entidad, ABC):
    """Clase abstracta para los servicios ofrecidos por Software FJ."""

    def __init__(self, codigo: str, nombre: str, tarifa_base: float, activo: bool = True):
        super().__init__(codigo)
        if not isinstance(nombre, str) or not nombre.strip():
            raise ValidacionError("El nombre del servicio es obligatorio.")
        if not isinstance(tarifa_base, (int, float)) or isinstance(tarifa_base, bool) or tarifa_base <= 0:
            raise ValidacionError("La tarifa base debe ser un número positivo.")
        self._nombre = nombre.strip()
        self._tarifa_base = float(tarifa_base)
        self._activo = bool(activo)

    @property
    def nombre(self) -> str:
        return self._nombre

    @property
    def activo(self) -> bool:
        return self._activo

    def validar_disponibilidad(self) -> None:
        if not self._activo:
            raise ServicioNoDisponibleError(f"El servicio '{self.nombre}' no está disponible.")

    @abstractmethod
    def calcular_costo(self, duracion: float, impuesto: float = 0.0, descuento: float = 0.0) -> float:
        """Calcula el costo aplicando las reglas particulares del servicio."""

    @abstractmethod
    def describir(self) -> str:
        """Describe el servicio."""

    def resumen(self) -> str:
        return f"{self.nombre} ({self.identificador})"


class ReservaSala(Servicio):
    """Reserva de salas; la tarifa se calcula por hora."""

    def calcular_costo(self, duracion: float, impuesto: float = 0.0, descuento: float = 0.0) -> float:
        self._validar_duracion(duracion)
        return self._aplicar_ajustes(self._tarifa_base * duracion, impuesto, descuento)

    def describir(self) -> str:
        return f"Alquiler de sala por hora: ${self._tarifa_base:,.0f}"


class AlquilerEquipo(Servicio):
    """Alquiler de equipos; aplica recargo fijo de mantenimiento."""

    def calcular_costo(self, duracion: float, impuesto: float = 0.0, descuento: float = 0.0) -> float:
        self._validar_duracion(duracion)
        subtotal = (self._tarifa_base * duracion) + 15000
        return self._aplicar_ajustes(subtotal, impuesto, descuento)

    def describir(self) -> str:
        return f"Alquiler de equipo por unidad de tiempo, más mantenimiento: ${self._tarifa_base:,.0f}"


class AsesoriaEspecializada(Servicio):
    """Asesoría especializada; se factura por sesión."""

    def calcular_costo(self, duracion: float, impuesto: float = 0.0, descuento: float = 0.0) -> float:
        self._validar_duracion(duracion)
        if duracion > 8:
            raise ValidacionError("Una asesoría no puede superar 8 horas por reserva.")
        return self._aplicar_ajustes(self._tarifa_base * duracion * 1.20, impuesto, descuento)

    def describir(self) -> str:
        return f"Asesoría especializada con factor profesional 1.20: ${self._tarifa_base:,.0f}"


# Funciones auxiliares de Servicio: se definen fuera de la jerarquía concreta
def _validar_duracion(duracion: float) -> None:
    if not isinstance(duracion, (int, float)) or isinstance(duracion, bool) or duracion <= 0:
        raise ValidacionError("La duración debe ser un número positivo.")


def _aplicar_ajustes(subtotal: float, impuesto: float, descuento: float) -> float:
    if not 0 <= impuesto <= 1:
        raise ValidacionError("El impuesto debe expresarse entre 0 y 1.")
    if not 0 <= descuento <= 1:
        raise ValidacionError("El descuento debe expresarse entre 0 y 1.")
    total = subtotal * (1 - descuento) * (1 + impuesto)
    if total < 0:
        raise ValidacionError("El cálculo produjo un total inconsistente.")
    return round(total, 2)


# Vinculamos los métodos comunes a la clase abstracta para evitar duplicación.
Servicio._validar_duracion = staticmethod(_validar_duracion)
Servicio._aplicar_ajustes = staticmethod(_aplicar_ajustes)


# -------------------------------- Reserva ----------------------------------

class EstadoReserva(Enum):
    PENDIENTE = "Pendiente"
    CONFIRMADA = "Confirmada"
    CANCELADA = "Cancelada"


class Reserva(Entidad):
    """Integra cliente, servicio, duración, costo y estado de la reserva."""

    _consecutivo = 1

    def __init__(self, cliente: Cliente, servicio: Servicio, duracion: float):
        codigo = f"RES-{Reserva._consecutivo:04d}"
        super().__init__(codigo)
        Reserva._consecutivo += 1
        if not isinstance(cliente, Cliente):
            raise ValidacionError("Debe proporcionar un objeto Cliente válido.")
        if not isinstance(servicio, Servicio):
            raise ValidacionError("Debe proporcionar un objeto Servicio válido.")
        _validar_duracion(duracion)
        servicio.validar_disponibilidad()
        self.cliente = cliente
        self.servicio = servicio
        self.duracion = float(duracion)
        self.estado = EstadoReserva.PENDIENTE
        self.total: Optional[float] = None
        logger.info("Reserva %s creada para %s.", self.identificador, cliente.nombre)

    def confirmar(self, impuesto: float = 0.19, descuento: float = 0.0) -> float:
        if self.estado != EstadoReserva.PENDIENTE:
            raise ReservaError("Solo se pueden confirmar reservas pendientes.")
        try:
            self.total = self.servicio.calcular_costo(self.duracion, impuesto, descuento)
        except ValidacionError as exc:
            logger.exception("Error al calcular el costo de %s.", self.identificador)
            raise ReservaError("No fue posible procesar el costo de la reserva.") from exc
        else:
            self.estado = EstadoReserva.CONFIRMADA
            logger.info("Reserva %s confirmada. Total: %.2f.", self.identificador, self.total)
            return self.total
        finally:
            logger.info("Finalizó el intento de confirmación de %s.", self.identificador)

    def cancelar(self) -> None:
        if self.estado == EstadoReserva.CANCELADA:
            raise ReservaError("La reserva ya se encuentra cancelada.")
        self.estado = EstadoReserva.CANCELADA
        logger.warning("Reserva %s cancelada.", self.identificador)

    def resumen(self) -> str:
        return (f"{self.identificador} | {self.cliente.nombre} | {self.servicio.nombre} | "
                f"{self.duracion} unidades | {self.estado.value} | Total: {self.total}")


# ----------------------------- Gestor del sistema --------------------------

class SistemaSoftwareFJ:
    """Administra colecciones en memoria sin utilizar bases de datos."""

    def __init__(self):
        self.clientes: list[Cliente] = []
        self.servicios: list[Servicio] = []
        self.reservas: list[Reserva] = []

    def registrar_cliente(self, cliente: Cliente) -> None:
        if any(c.identificador == cliente.identificador for c in self.clientes):
            raise ClienteDuplicadoError(f"Ya existe el documento {cliente.identificador}.")
        self.clientes.append(cliente)
        logger.info("Cliente registrado: %s.", cliente.identificador)

    def agregar_servicio(self, servicio: Servicio) -> None:
        if any(s.identificador == servicio.identificador for s in self.servicios):
            raise ValidacionError(f"Ya existe el código de servicio {servicio.identificador}.")
        self.servicios.append(servicio)
        logger.info("Servicio agregado: %s.", servicio.identificador)

    def crear_reserva(self, cliente: Cliente, servicio: Servicio, duracion: float) -> Reserva:
        if cliente not in self.clientes:
            raise ValidacionError("El cliente no está registrado en el sistema.")
        if servicio not in self.servicios:
            raise ValidacionError("El servicio no está registrado en el sistema.")
        reserva = Reserva(cliente, servicio, duracion)
        self.reservas.append(reserva)
        return reserva

    def calcular_costo(self, servicio: Servicio, duracion: float) -> float:
        """Variante básica del cálculo sobrecargado: tarifa sin ajustes."""
        return servicio.calcular_costo(duracion)

    def calcular_costo_detallado(
        self, servicio: Servicio, duracion: float, impuesto: float, descuento: float
    ) -> float:
        """Variante detallada: permite impuesto y descuento."""
        return servicio.calcular_costo(duracion, impuesto, descuento)

    def mostrar_resumen(self) -> None:
        print("\\n--- RESUMEN DEL SISTEMA SOFTWARE FJ ---")
        print(f"Clientes: {len(self.clientes)} | Servicios: {len(self.servicios)} | Reservas: {len(self.reservas)}")
        for reserva in self.reservas:
            print(reserva.resumen())


# ------------------------------- Demostración ------------------------------

def ejecutar_operacion(numero: int, descripcion: str, accion) -> None:
    """Ejecuta una operación aislada: registra el error y permite continuar."""
    print(f"\\nOperación {numero}: {descripcion}")
    try:
        accion()
    except SoftwareFJError as exc:
        logger.exception("Operación %s fallida: %s", numero, descripcion)
        print(f"Error controlado: {exc}")
    except (TypeError, ValueError) as exc:
        logger.exception("Error de tipo/valor en operación %s.", numero)
        print(f"Error de datos: {exc}")
    except Exception as exc:
        logger.exception("Error inesperado en operación %s.", numero)
        print(f"Error inesperado controlado: {exc}")
    else:
        print("Operación realizada correctamente.")
    finally:
        print("La aplicación continúa activa.")


def main() -> None:
    sistema = SistemaSoftwareFJ()

    def crear_clientes():
        c1 = Cliente("100100100", "Ana Pérez", "ana@correo.com", "3001234567")
        c2 = Cliente("200200200", "Luis Gómez", "luis@correo.com", "3117654321")
        sistema.registrar_cliente(c1)
        sistema.registrar_cliente(c2)
        sistema.cliente_demo = c1
        sistema.cliente_dos = c2

    ejecutar_operacion(1, "Registro de dos clientes válidos", crear_clientes)
    ejecutar_operacion(2, "Registro de cliente con correo inválido",
                       lambda: Cliente("300300300", "Marta Díaz", "correo-invalido", "3001234567"))
    ejecutar_operacion(3, "Intento de documento duplicado",
                       lambda: sistema.registrar_cliente(Cliente("100100100", "Otro Nombre", "otro@correo.com", "3001234567")))

    def crear_servicios():
        sala = ReservaSala("S01", "Sala de reuniones", 50000)
        equipo = AlquilerEquipo("E01", "Video proyector", 30000)
        asesoria = AsesoriaEspecializada("A01", "Asesoría tecnológica", 80000)
        sistema.agregar_servicio(sala)
        sistema.agregar_servicio(equipo)
        sistema.agregar_servicio(asesoria)
        sistema.sala_demo, sistema.equipo_demo, sistema.asesoria_demo = sala, equipo, asesoria

    ejecutar_operacion(4, "Creación de tres servicios especializados", crear_servicios)
    ejecutar_operacion(5, "Creación de servicio con tarifa negativa",
                       lambda: ReservaSala("S02", "Sala inválida", -1000))
    ejecutar_operacion(6, "Cálculo polimórfico del costo de sala",
                       lambda: print("Costo:", sistema.calcular_costo(sistema.sala_demo, 2)))
    ejecutar_operacion(7, "Cálculo con impuesto y descuento",
                       lambda: print("Costo ajustado:", sistema.calcular_costo_detallado(
                           sistema.equipo_demo, 2, 0.19, 0.10)))

    def reserva_exitosa():
        reserva = sistema.crear_reserva(sistema.cliente_demo, sistema.sala_demo, 2)
        print("Total confirmado:", reserva.confirmar(impuesto=0.19, descuento=0.05))

    ejecutar_operacion(8, "Creación y confirmación de reserva exitosa", reserva_exitosa)
    ejecutar_operacion(9, "Intento de reserva con duración inválida",
                       lambda: sistema.crear_reserva(sistema.cliente_demo, sistema.sala_demo, -3))
    ejecutar_operacion(10, "Intento de reservar servicio inexistente",
                       lambda: sistema.crear_reserva(sistema.cliente_demo, ReservaSala("TEMP", "Temporal", 1000), 1))

    def reserva_asesoria_invalida():
        reserva = sistema.crear_reserva(sistema.cliente_dos, sistema.asesoria_demo, 10)
        reserva.confirmar()

    ejecutar_operacion(11, "Asesoría con duración superior al límite", reserva_asesoria_invalida)

    def reserva_cancelada():
        reserva = sistema.crear_reserva(sistema.cliente_dos, sistema.equipo_demo, 1)
        reserva.cancelar()
        print("Estado:", reserva.estado.value)

    ejecutar_operacion(12, "Creación y cancelación de reserva", reserva_cancelada)

    sistema.mostrar_resumen()
    print(f"\\nRegistro de eventos y errores: {LOG_DIR / 'software_fj.log'}")
    print("Demostración finalizada: el sistema permaneció activo.")


if __name__ == "__main__":
    main()
